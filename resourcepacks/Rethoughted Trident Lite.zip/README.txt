This resourcepack made by CatFromNet
Version - 0.5

Project links:

https://modrinth.com/resourcepack/rethoughted-trident - Modrinth
https://www.curseforge.com/minecraft/texture-packs/rethoughted-trident - CurseForge

catfromnet - authors discord
https://discord.gg/q29y59SWEu - discord server
